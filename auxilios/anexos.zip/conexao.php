<?php

$user = 'root';
$password = '';

$conn = new PDO('mysql:host=localhost;port=13306;dbname=nome_pdo', $user, $password);

?>