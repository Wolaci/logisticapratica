<?php  session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Email no-reply</title>
</head>
<body>
<div class="conteudo" style="margin: auto;width: 100%;max-width: 550px;text-align: center;">
<h1><b><i>Segue o link da video aula de sub-redes e alguns anexos</i></b></h1>
<h4>Link:--> https://www.youtube.com/watch?v=T_WB5ftfPkc  (Minha Aula) <--</h4>
<h4>Link2:--> https://www.youtube.com/watch?v=GGmhv1Wz6fc&t=662s  <--</h4>
<h4>Link3:--> https://www.youtube.com/watch?v=7tUEHsQR9ak&t=1209s (Teoria Completa) <--</h4>
<h3 style="color:red;">Link4:--> https://www.todoespacoonline.com/w/2015/06/calculo-de-sub-redes-ipv4/ (Site para leitura) <--</h3>
	<img src="Darth.png" alt=""><br>
	<p><b><i>Que a força esteja com você meu nobre.</i></b></p>
	<p style="color:red;"><b><i>Email (Automático no-reply)</i></b></p>
	<h3 style="color:green;">V V V Arquivos V V V V</h3>
</div>
</body>
</html>