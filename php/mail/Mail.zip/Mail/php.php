<?php 
$a = file_get_contents('https://www.todoespacoonline.com/w/2015/06/calculo-de-sub-redes-ipv4/');
echo $a;

 ?>